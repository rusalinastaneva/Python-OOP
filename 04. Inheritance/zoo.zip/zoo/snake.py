from zoo.reptile import Reptile


class Snake(Reptile):
    pass