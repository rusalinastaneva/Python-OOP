from zoo.animal import Animal


class Mammal(Animal):
    pass