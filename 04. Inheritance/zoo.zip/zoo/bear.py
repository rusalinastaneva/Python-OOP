from zoo.mammal import Mammal


class Gorilla(Mammal):
    pass