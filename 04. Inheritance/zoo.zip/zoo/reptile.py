from zoo.animal import Animal


class Reptile(Animal):
    pass