from zoo.reptile import Reptile


class Lizard(Reptile):
    pass