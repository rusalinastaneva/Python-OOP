from abc import ABC, abstractmethod


class Player(ABC):
    @abstractmethod
    def __init__(self, username, health):
        self.__username = username
        self.__health = health

    @property
    def username(self):
        pass

    @username.setter
    def username(self, value):
        pass

    @property
    def health(self):
        return

    @health.setter
    def health(self, value):
        pass

    def take_damage(self, damage):
        pass

