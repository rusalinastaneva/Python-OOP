class PlayerRepository:
    def __init__(self):
        pass

    def add(self, player):
        pass

    def remove(self, player):
        pass

    def find(self, username):
        pass

