class Controller:
    def __init__(self):
        pass

    def add_player(self, type, username):
        pass

    def add_card(self, type, name):
        pass

    def add_player_card(self, username, card_name):
        pass

    def fight(self, attack_name, enemy_name):
        pass

    def report(self):
        pass
    
