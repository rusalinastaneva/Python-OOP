from abc import ABC, abstractmethod

class Card(ABC):
    def __init__(self):
        pass

    @property
    def name(self):
        pass

    @name.setter
    def name(self, value):
        pass

    @property
    def damage_points(self):
        pass

    @damage_points.setter
    def damage_points(self, value):
        pass

    @property
    def health_points(self):
        pass

    @health_points.setter
    def health_points(self, value):
        pass
