class CardRepository:
    def __init__(self):
        pass

    def add(self, card):
        pass

    def remove(self, card):
        pass

    def find(self, name):
        pass

