from project.card.card import Card


class TrapCard(Card):
    def __init__(self):
        pass