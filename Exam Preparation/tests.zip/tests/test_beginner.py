import unittest

from project.player.beginner import Beginner


class TestsAdvancedPlayer(unittest.TestCase):
    def setUp(self):
        self.player = Beginner("Toshko")

    def test_init_should_create_correct_attributes(self):
        self.assertEqual(self.player.username, "Toshko")
        self.assertEqual(self.player.health, 50)
        self.assertEqual(self.player.card_repository.__class__.__name__, "CardRepository")


if __name__ == "__main__":
    unittest.main()
