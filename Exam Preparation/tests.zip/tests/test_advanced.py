import unittest

from project.player.advanced import Advanced


class TestsAdvancedPlayer(unittest.TestCase):
    def setUp(self):
        self.player = Advanced("Toshko")

    def test_init_should_create_player_attributes(self):
        self.assertEqual(self.player.username, "Toshko")
        self.assertEqual(self.player.health, 250)
        self.assertEqual(self.player.card_repository.__class__.__name__, "CardRepository")

    def test_username_setter_empty_string_should_raise_error(self):
        with self.assertRaises(ValueError) as context:
            self.player.username = ""
        self.assertEqual(str(context.exception), "Player's username cannot be an empty string.")

    def test_health_setter_negative_value_should_raise_error(self):
        with self.assertRaises(ValueError) as context:
            self.player.health = -50
        self.assertEqual(str(context.exception), "Player's health bonus cannot be less than zero.")

    def test_take_damage_negative_damage_should_raise_error(self):
        with self.assertRaises(ValueError) as context:
            self.player.take_damage(-20)
        self.assertEqual(str(context.exception), "Damage points cannot be less than zero.")

    def test_take_damage_damage_should_decrease_health(self):
        damage_points = 50
        self.player.take_damage(damage_points)

        expected = 200
        actual = self.player.health
        self.assertEqual(actual, expected)

    def test_is_dead_return_True_if_health_is_negative(self):
        self.player.health = 0

        expected = True
        actual = self.player.is_dead
        self.assertEqual(actual, expected)
        # self.assertTrue(actual)

    def test_is_dead_return_False_if_health_is_valid(self):
        actual = self.player.is_dead
        self.assertFalse(actual)
        # self.assertEqual(actual, False)


if __name__ == "__main__":
    unittest.main()
