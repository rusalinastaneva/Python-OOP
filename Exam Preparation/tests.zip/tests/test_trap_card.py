import unittest

from project.card.trap_card import TrapCard


class TestsTrapCard(unittest.TestCase):
    def setUp(self):
        self.card = TrapCard("Ace")

    def test_init_should_create_correct_attributes(self):
        self.assertEqual(self.card.name, "Ace")
        self.assertEqual(self.card.damage_points, 120)
        self.assertEqual(self.card.health_points, 5)

if __name__ == "__main__":
    unittest.main()