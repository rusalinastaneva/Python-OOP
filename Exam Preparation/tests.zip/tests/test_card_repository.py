# import unittest
#
# from project.card.card_repository import CardRepository
# from project.card.magic_card import MagicCard
#
#
# class TestsCardRepository(unittest.TestCase):
#     def setUp(self):
#         self.cardRepository = CardRepository()
#
#     def test_init_create_empty_cards_list(self):
#         self.assertEqual(self.cardRepository.cards, [])
#
#     def test_property_count_return_0_for_empty_cards_list(self):
#         actual = self.cardRepository.count
#         self.assertEqual(actual, 0)
#
#     def test_add_should_add_card_object_to_cards_if_does_not_exist(self):
#         card = MagicCard("King")
#         self.cardRepository.add(card)
#         actual = self.cardRepository.cards.name
#         self.assertEqual(actual, "King")
#
#
