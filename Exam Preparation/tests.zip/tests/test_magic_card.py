import unittest

from project.card.magic_card import MagicCard


class TestsMagicCard(unittest.TestCase):
    def setUp(self):
        self.card = MagicCard("Ace")

    def test_init_should_create_correct_attributes(self):
        self.assertEqual(self.card.name, "Ace")
        self.assertEqual(self.card.damage_points, 5)
        self.assertEqual(self.card.health_points, 80)

    def test_name_setter_empty_string_should_raise_error(self):
        with self.assertRaises(ValueError) as context:
            self.card.name = ""
        self.assertEqual(str(context.exception), "Card's name cannot be an empty string.")

    def test_damage_points_setter_negative_value_should_raise_error(self):
        with self.assertRaises(ValueError) as context:
            self.card.damage_points = -5
        self.assertEqual(str(context.exception), "Card's damage points cannot be less than zero.")

    def test_health_points_setter_negative_value_should_raise_error(self):
        with self.assertRaises(ValueError) as context:
            self.card.health_points = -5
        self.assertEqual(str(context.exception), "Card's HP cannot be less than zero.")

if __name__ == "__main__":
    unittest.main()